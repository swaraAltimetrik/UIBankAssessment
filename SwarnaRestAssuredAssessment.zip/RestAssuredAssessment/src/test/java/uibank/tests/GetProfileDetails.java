package uibank.tests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import uibank.base.BaseAPI;

public class GetProfileDetails extends BaseAPI {

	@Test(dependsOnMethods = "uibank.tests.LoginUiBank.validateLogin")
	public void validateGetProfileDetails() {
		// BaseAPI class sets the BaseURI
		// request type
		Response response = RestAssured
				.given()
				.log()
				.all()
				.contentType(ContentType.JSON)
				.header("authorization", id)
				.get("users/userId");

		// print status code
		System.err.println(response.statusCode());
		
		//print response body
		response.prettyPrint();
		

		// asserting status code, to see if it is 200
		assertEquals(response.statusCode(), 200);
	}
}
