package uibank.tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import uibank.base.BaseAPI;

public class LoginUiBank extends BaseAPI {

	@Test
	public void validateLogin() {
		//BaseAPI class sets the BaseURI
		
		// request type
		Response response = RestAssured.given()
				.log().all()
				.contentType(ContentType.JSON)
				.body("{\"username\": \"Swarna4489\",\"password\": \"Navya@1620\"}")
				.post("users/login");
		
		// print status code
		System.err.println(response.statusCode());
		
		//print response body
		response.prettyPrint();
		
		//asserting status code, to see if it is equal to 200
		assertEquals(response.statusCode(), 200);
		
		//setting id and userId globally to be accessed by other apis
		JsonPath jsonPath = response.jsonPath();
		id = jsonPath.get("id");
		userId = jsonPath.get("userId");

	}

}
