package uibank.tests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import uibank.base.BaseAPI;

public class CreateUiBankAccount extends BaseAPI {
	@Test(dependsOnMethods = "uibank.tests.LoginUiBank.validateLogin")
	public void getCreateAccount() {
		// BaseURI is set in the BaseAPI base class
		
        //request type
		Response response = RestAssured.given()
				.log()
				.all()
				.contentType(ContentType.JSON)
				.body(
				"{\"friendlyName\":\"SwarnaAccount\",\"type\":\"savings\",\"userId\":\"620f1d858932d4005f2a8873\",\"balance\":100,\"accountNumber\":64107274}")
				.header("authorization", id)
				.post("accounts");
		
		// print status code
		System.err.println(response.statusCode());
		
		//print response body
		response.prettyPrint();

		// assert response code to check if it is equal to 200
		assertEquals(response.statusCode(), 200);

	}
}
