package uibank.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import io.restassured.RestAssured;

public class BaseAPI {

	public static String id = "";
	public static String userId = "";


	@BeforeMethod
	public void getBaseUri() {
		//loads property file "config.properties"
		Properties prop = loadPropertyFile();
		
		//build the baseURI using properties read from property file
		RestAssured.baseURI = prop.getProperty("url") + "/" + prop.getProperty("resources") + "/";


	}

	/** reads property file stored in resources */
	public static Properties loadPropertyFile() {
		Properties prop = new Properties();

		try {
			prop.load(new FileInputStream(new File("./resources/config.properties")));

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return prop;
	}

}